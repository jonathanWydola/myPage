Jonathan Wydola
GUI 1

10/04/2016 
UMS:01195746

This is for Assignment 4.
I have completed the assignment proving that i can style a page using 
css and semantics. 

I have passed the validation for the assignment and have compressed my public_html folder and submitted it since i have many files now.

the link to my page is 
http://www.weblab.cs.uml.edu/~jwydola
