This file contains any extra informatino regarding my assignment.
I have attached a styles.css sheet for my stylesheet.
i have also added a gif file that is included as my logo on my webpage.